//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "MenuModel.h"

@implementation MenuModel


- (NSDictionary*)attributeMapDictionary
{
	return @{@"ItemID": @"ItemID"
             ,@"ItemName": @"ItemName"
             ,@"ItemImage": @"ItemImage"
             ,@"ItemPrice": @"ItemPrice"
             ,@"ItemType": @"ItemType"};
}

@end
