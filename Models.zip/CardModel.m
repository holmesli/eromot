//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "CardModel.h"

@implementation CardModel

- (NSDictionary*)attributeMapDictionary
{
	return @{@"CardID": @"CardID"
             ,@"CardType": @"CardType"
             ,@"CardTitle": @"CardTitle"
             ,@"CardBarcode": @"CardBarcode"
             ,@"CardNumber": @"CardNumber"
             ,@"CardDes": @"CardDes"
             ,@"FrontViewImage": @"FrontViewImage"
             ,@"BackViewImage": @"BackViewImage"};
}

-(BOOL)hasFrontImage
{
    return (_FrontViewImage && [_FrontViewImage length] > 0);
}

-(BOOL)hasBackImage
{
    return (_BackViewImage && [_BackViewImage length] > 0);
}


@end
