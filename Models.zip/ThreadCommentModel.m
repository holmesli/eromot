//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "ThreadCommentModel.h"

@implementation ThreadCommentModel


- (NSDictionary*)attributeMapDictionary
{
	return @{@"ThreadID": @"ThreadID"
             ,@"ThreadTitle": @"ThreadTitle"
             ,@"ThreadPostDate": @"ThreadPostDate"
             ,@"ThreadUpdateDate": @"ThreadUpdateDate"
             ,@"ThreadContent": @"ThreadContent"
             ,@"ThreadImages": @"ThreadImages"
             ,@"ThreadType": @"ThreadType"
             ,@"MemberID": @"MemberID"
             ,@"AccountName": @"AccountName"
             ,@"TimeDiff":@"TimeDiff"
             ,@"MemberImage":@"MemberImage"};
}

@end
