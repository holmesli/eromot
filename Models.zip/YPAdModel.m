//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "YPAdModel.h"

@implementation YPAdModel

- (NSDictionary*)attributeMapDictionary
{
	return @{@"AdID": @"AdID"
             ,@"Title": @"Title"
             ,@"Content": @"Content"
             ,@"ServiceRegion": @"ServiceRegion"
             ,@"Address": @"Address"
             ,@"DeliverPrice": @"DeliverPrice"
             ,@"Longitude": @"Longitude"
             ,@"Latitude": @"Latitude"
             ,@"MemberID": @"MemberID"
             ,@"PostDate": @"PostDate"
             ,@"UpdateDate": @"UpdateDate"
             ,@"AccountName": @"AccountName"
             ,@"Email": @"Email"
             ,@"Phone1": @"Phone1"
             ,@"Phone2": @"Phone2"
             ,@"Role": @"Role"
             ,@"Contact":@"Contact"
             ,@"Language_M":@"Language_M"
             ,@"Language_C":@"Language_C"
             ,@"Language_E":@"Language_E"
             ,@"Url":@"Url"};
}

@end
