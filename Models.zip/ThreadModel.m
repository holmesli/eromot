//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "ThreadModel.h"

@implementation ThreadModel
@synthesize listImage;

- (NSDictionary*)attributeMapDictionary
{
	return @{@"ThreadID": @"ThreadID"
             ,@"ThreadTitle": @"ThreadTitle"
             ,@"ThreadPostDate": @"ThreadPostDate"
             ,@"ThreadUpdateDate": @"ThreadUpdateDate"
             ,@"ThreadContent": @"ThreadContent"
             ,@"ThreadType": @"ThreadType"
             ,@"LastCommentDate": @"LastCommentDate"
             ,DUMP_KEY: @"ThreadImages"
             ,@"MemberID": @"MemberID"
             ,DUMP_KEY:@"LikeList"
             ,DUMP_KEY:@"Comments"
             ,@"AccountName":@"AccountName"
             ,@"MemberImage":@"MemberImage"
             ,@"TimeDiff":@"TimeDiff"};
}


- (id)init
{
    self = [super init];
    if (self) {
        self.listImage = [[NSMutableArray alloc] initWithCapacity:10];
        self.listComments =[[NSMutableArray alloc] initWithCapacity:10];
        self.listLike = [[NSMutableArray alloc] initWithCapacity:10];
    }
    return self;
}

- (void)addLikeList:(LikeModel *)aLike
{
    if (!self.listLike) {
        self.listLike = [[NSMutableArray alloc] initWithCapacity:2];
    }
    [self.listLike addObject:aLike];
    
}
- (void)addLikeCommentsList:(LikeComments *)likeComment
{
    
    if (!self.listComments) {
        self.listComments = [[NSMutableArray alloc] initWithCapacity:2];
    }
    [self.listComments addObject:likeComment];
}

- (void)addImageToList:(ThreadImageModel *)aImage
{
    if (!self.listImage) {
        self.listImage = [[NSMutableArray alloc] initWithCapacity:2];
    }
    [self.listImage addObject:aImage];
}

@end
