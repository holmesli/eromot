//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface FollowModel : ITTBaseModelObject

@property (nonatomic,strong) NSString *MemberID;
@property (nonatomic,strong) NSString *AccountName;
@property (nonatomic,strong) NSString *MemberImage;
@property (nonatomic, strong) NSString *followed;
@end
