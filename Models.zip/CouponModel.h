//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface CouponModel : ITTBaseModelObject
{    NSString *_CouponID;
    NSString *_Image;
    NSString *_ThumbImage;
    NSString *_CreateDate;
    NSString *_ExpireDate;
    NSString *_Title;
    NSString *_Description;
}

@property (nonatomic,strong) NSString *CouponID;
@property (nonatomic,strong) NSString *Image;
@property (nonatomic,strong) NSString *ThumbImage;
@property (nonatomic,strong) NSString *CreateDate;
@property (nonatomic,strong) NSString *ExpireDate;
@property (nonatomic,strong) NSString *Title;
@property (nonatomic,strong) NSString *Description;

@end
