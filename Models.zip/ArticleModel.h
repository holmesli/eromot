//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface ArticleModel : ITTBaseModelObject

@property (nonatomic, strong) NSString *ArticleTitle;
@property (nonatomic, strong) NSString *ArticleContent;
@property (nonatomic, strong) NSString *ArticleLargeImage;
@property (nonatomic, strong) NSString *ArticleSmallImage;
@property (nonatomic, strong) NSString *ImagePosition;
@property (nonatomic, strong) NSString *ArticleDate;
@property (nonatomic, strong) NSString *Author;
@property (nonatomic, strong) NSString *ArticleIssue;
@property (nonatomic, strong) NSString *DisplayStyle;
@property (nonatomic, strong) NSString *ArticleID;
@property (nonatomic, strong) NSString *ArticleVideo;
@property (nonatomic, strong) NSString *VideoUrl;
@property (nonatomic, strong) NSString *TextUrl;

@end
