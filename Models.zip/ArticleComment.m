//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "ArticleComment.h"

@implementation ArticleComment

- (NSDictionary*)attributeMapDictionary
{
	return @{@"CommentID": @"CommentID"
             ,@"MemberID": @"MemberID"
             ,@"CommentContent": @"CommentContent"
             ,@"PostDate": @"PostDate"
             ,@"UpdateDate": @"UpdateDate"
             ,@"AccountName": @"AccountName"
             ,@"TimeDiff":@"TimeDiff"};
}


@end
