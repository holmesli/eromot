//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface UserModel : ITTBaseModelObject

@property (nonatomic,strong) NSString *memberID;
@property (nonatomic,strong) NSString *school;
@property (nonatomic,strong) NSString *major;
@property (nonatomic,strong) NSString *address;
@property (nonatomic,strong) NSString *city;
@property (nonatomic,strong) NSString *province;
@property (nonatomic,strong) NSString *postalCode;
@property (nonatomic,strong) NSString *profileImage;
@property (nonatomic,strong) NSString *accountName;
@property (nonatomic,strong) NSString *status;
@property (nonatomic,strong) NSString *email;
@property (nonatomic,strong) NSString *phone;
@property (nonatomic,strong) NSString *LastLoginDate;
@property (nonatomic,strong) NSString *role;
@property (nonatomic,strong) NSString *totalThread;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *gender;
@property (nonatomic, strong) NSString *followingNum;
@property (nonatomic, strong) NSString *followedNum;
@property (nonatomic, strong) NSString *followed;
@end
