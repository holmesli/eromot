//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"
#import "RestModel.h"

@interface BaseResetModel : ITTBaseModelObject

@property (nonatomic, strong) NSString *downtown;
@property (nonatomic, strong) NSString *eastYork;
@property (nonatomic, strong) NSString *northYork;
@property (nonatomic, strong) NSString *scarborough;
@property (nonatomic, strong) NSString *markham;
@property (nonatomic, strong) NSString *mississauga;
@property (nonatomic, strong) NSString *vaughan;
@property (nonatomic, strong) NSString *richmondHill;
@property (nonatomic, strong) NSString *others;
@property (nonatomic, strong) NSString *total;

@property (nonatomic, strong) NSMutableArray *downtownList;
@property (nonatomic, strong) NSMutableArray *eastYorkList;
@property (nonatomic, strong) NSMutableArray *northYorkList;
@property (nonatomic, strong) NSMutableArray *scarboroughList;
@property (nonatomic, strong) NSMutableArray *markhamList;
@property (nonatomic, strong) NSMutableArray *mississaugaList;
@property (nonatomic, strong) NSMutableArray *vaughanList;
@property (nonatomic, strong) NSMutableArray *richmondHillList;
@property (nonatomic, strong) NSMutableArray *othersList;


- (void)downtownToList:(RestModel *)aRestModel;
- (void)eastYorkToList:(RestModel *)aRestModel;
- (void)northYorkToList:(RestModel *)aRestModel;
- (void)scarboroughToList:(RestModel *)aRestModel;
- (void)markhamToList:(RestModel *)aRestModel;
- (void)mississaugaToList:(RestModel *)aRestModel;
- (void)vaughanToList:(RestModel *)aRestModel;
- (void)richmondToHillList:(RestModel *)aRestModel;
- (void)othersToList:(RestModel *)aRestModel;

@end
