//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "ThreadImageModel.h"

@implementation ThreadImageModel


- (NSDictionary*)attributeMapDictionary
{
	return @{@"ImageID": @"ImageID"
             ,@"ImageUrl": @"ImageUrl"
             ,@"ImageWidth": @"ImageWidth"
             ,@"ImageHeight": @"ImageHeight"
             };
}

- (id)init
{
    self = [super init];
    if (self) {
        //self.models = [NSMutableArray array];
    }
    return self;
}

@end
