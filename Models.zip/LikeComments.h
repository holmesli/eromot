//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface LikeComments : ITTBaseModelObject

@property (nonatomic,strong) NSString *CommentPostDate;
@property (nonatomic,strong) NSString *CommentContent;
@property (nonatomic,strong) NSString *MemberID;
@property (nonatomic,strong) NSString *AccountName;
@property (nonatomic,strong) NSString *MemberImage;

@end
