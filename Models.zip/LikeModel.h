//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface LikeModel : ITTBaseModelObject

@property (nonatomic,strong) NSString *AccountName;
@property (nonatomic,strong) NSString *Image;
@property (nonatomic, strong) NSString *MemberID;

@end
