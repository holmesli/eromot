//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "CouponModel.h"

@implementation CouponModel

- (NSDictionary*)attributeMapDictionary
{
	return @{@"CouponID": @"CouponID"
             ,@"Image": @"Image"
             ,@"ThumbImage": @"ThumbImage"
             ,@"CreateDate": @"CreateDate"
             ,@"ExpireDate": @"ExpireDate"
             ,@"Title": @"Title"
             ,@"Description": @"Description"};
}

@end
