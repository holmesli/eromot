//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "BaseResetModel.h"

@implementation BaseResetModel

- (id)init
{
    self = [super init];
    if (self) {
        self.downtownList = [[NSMutableArray alloc] initWithCapacity:0];
        self.eastYorkList = [[NSMutableArray alloc] initWithCapacity:0];
        self.northYorkList = [[NSMutableArray alloc] initWithCapacity:0];
        
        self.scarboroughList = [[NSMutableArray alloc] initWithCapacity:0];
        self.markhamList = [[NSMutableArray alloc] initWithCapacity:0];
        self.mississaugaList = [[NSMutableArray alloc] initWithCapacity:0];
        
        self.vaughanList = [[NSMutableArray alloc] initWithCapacity:0];
        self.richmondHillList = [[NSMutableArray alloc] initWithCapacity:0];
        self.othersList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    return self;
}



- (void)downtownToList:(RestModel *)aRestModel
{
    if(!self.downtownList)
    {
        self.downtownList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.downtownList addObject:aRestModel];
}
- (void)eastYorkToList:(RestModel *)aRestModel
{
    if(!self.eastYorkList)
    {
        self.eastYorkList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.eastYorkList addObject:aRestModel];
}
- (void)northYorkToList:(RestModel *)aRestModel
{
    if(!self.northYorkList)
    {
        self.northYorkList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.northYorkList addObject:aRestModel];
}
- (void)scarboroughToList:(RestModel *)aRestModel
{
    if(!self.scarboroughList)
    {
        self.scarboroughList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.scarboroughList addObject:aRestModel];
}
- (void)markhamToList:(RestModel *)aRestModel
{
    if(!self.markhamList)
    {
        self.markhamList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.markhamList addObject:aRestModel];
}
- (void)mississaugaToList:(RestModel *)aRestModel
{
    if(!self.mississaugaList)
    {
        self.mississaugaList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.mississaugaList addObject:aRestModel];
}
- (void)vaughanToList:(RestModel *)aRestModel
{
    if(!self.vaughanList)
    {
        self.vaughanList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.vaughanList addObject:aRestModel];
}
- (void)richmondToHillList:(RestModel *)aRestModel
{
    if(!self.richmondHillList)
    {
        self.richmondHillList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.richmondHillList addObject:aRestModel];
}
- (void)othersToList:(RestModel *)aRestModel
{
    if(!self.othersList)
    {
        self.othersList = [[NSMutableArray alloc] initWithCapacity:0];
    }
    [self.othersList addObject:aRestModel];
}

/**
    Key-Value pair by dictionary key name and property name.
    key:    property name
    value:  dictionary key name
 **/
- (NSDictionary*)attributeMapDictionary
{
	return @{
             @"DUMP_KEY1":@"northYork"
             ,@"DUMP_KEY2":@"downtown"
             ,@"DUMP_KEY3":@"scarborough"
             ,@"DUMP_KEY4":@"markham"
             ,@"DUMP_KEY5":@"mississauga"
             ,@"DUMP_KEY6":@"vaughan"
             ,@"DUMP_KEY7":@"richmondHill"
             ,@"DUMP_KEY8":@"others"
             ,@"DUMP_KEY9":@"eastYork"
             ,@"total":@"total"
             };
}

@end
