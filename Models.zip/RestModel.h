//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface RestModel : ITTBaseModelObject

@property (nonatomic,strong) NSString *AdID;
@property (nonatomic,strong) NSString *Title;
@property (nonatomic,strong) NSString *Content;
@property (nonatomic,strong) NSString *ServiceRegion;
@property (nonatomic,strong) NSString *Address;
@property (nonatomic,strong) NSString *DeliverPrice;
@property (nonatomic,strong) NSString *Longitude;
@property (nonatomic,strong) NSString *Latitude;
@property (nonatomic,strong) NSString *MemberID;
@property (nonatomic,strong) NSString *Image;
@property (nonatomic, strong) NSString *Phone;
@property (nonatomic,strong) NSString *Special;
@property (nonatomic, strong) NSString *Discount;

@end
