//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel


- (NSDictionary*)attributeMapDictionary
{
	return @{@"memberID": @"memberID"
             ,@"school": @"school"
             ,@"major": @"major"
             ,@"address": @"address"
             ,@"city": @"city"
             ,@"province": @"province"
             ,@"postalCode": @"postalCode"
             ,@"profileImage": @"profileImage"
             ,@"accountName": @"accountName"
             ,@"status": @"status"
             ,@"email": @"email"
             ,@"phone": @"phone"
             ,@"role": @"role"
             ,@"totalThread":@"totalThread"
             ,@"image":@"image"
             ,@"gender":@"gender"
             ,@"followingNum":@"followingNum"
             ,@"followedNum":@"followedNum"
             ,@"followed":@"followed"};
}
@end
