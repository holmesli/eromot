//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "LikeModel.h"

@implementation LikeModel


- (NSDictionary*)attributeMapDictionary
{
	return @{@"Image": @"Image"
             ,@"AccountName": @"AccountName"
             ,@"MemberID":@"MemberID"
             };
}

- (id)init
{
    self = [super init];
    if (self) {
        //self.models = [NSMutableArray array];
    }
    return self;
}

@end
