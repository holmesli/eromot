//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "YPCategoryModel.h"

@implementation YPCategoryModel

- (NSDictionary*)attributeMapDictionary
{
	return @{@"IconID": @"IconID"
             ,@"Type": @"Type"
             ,@"Name": @"Name"
             ,@"Image": @"Image"};
}

@end
