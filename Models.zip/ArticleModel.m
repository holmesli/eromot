//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "ArticleModel.h"

@implementation ArticleModel

- (NSDictionary*)attributeMapDictionary
{
	return @{@"ArticleTitle": @"ArticleTitle"
             ,@"ArticleContent": @"ArticleContent"
             ,@"ArticleLargeImage": @"ArticleLargeImage"
             ,@"ArticleSmallImage": @"ArticleSmallImage"
             ,@"ImagePosition": @"ImagePosition"
             ,@"ArticleDate": @"ArticleDate"
             ,@"Author": @"Author"
             ,@"ArticleIssue": @"ArticleIssue"
             ,@"DisplayStyle": @"DisplayStyle"
             ,@"ArticleID":@"ArticleID"
             ,@"ArticleVideo":@"ArticleVideo"
             ,@"VideoUrl":@"VideoUrl"
             ,@"TextUrl":@"TextUrl"};
}

@end
