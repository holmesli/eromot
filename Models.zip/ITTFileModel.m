//
//  ITTFileModel.m
//  iTotemFramework
//
//  Created by Sword Zhou on 8/8/13.
//  Copyright (c) 2013 iTotemStudio. All rights reserved.
//

#import "ITTFileModel.h"

@implementation ITTFileModel


- (NSString*)mimeType
{
    return nil == _mimeType?@"":_mimeType;
}

@end
