//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "RestModel.h"

@implementation RestModel


- (NSDictionary*)attributeMapDictionary
{
	return @{@"AdID": @"AdID"
             ,@"Title": @"Title"
             ,@"Content": @"Content"
             ,@"ServiceRegion": @"ServiceRegion"
             ,@"Address": @"Address"
             ,@"DeliverPrice": @"DeliverPrice"
             ,@"Longitude": @"Longitude"
             ,@"Latitude": @"Latitude"
             ,@"MemberID": @"MemberID"
             ,@"Image": @"Image"
             ,@"Phone": @"Phone"
             ,@"Special":@"Special"
             ,@"Discount":@"Discount"
             };
}

@end
