//
//  Car.h
//  iTotemFrame
////  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface YPCategoryModel : ITTBaseModelObject
{    NSString *_IconID;
    NSString *_Type;
    NSString *_Name;
    NSString *_Image;
}
@property (nonatomic,strong) NSString *IconID;
@property (nonatomic,strong) NSString *Type;
@property (nonatomic,strong) NSString *Name;
@property (nonatomic,strong) NSString *Image;

@end
