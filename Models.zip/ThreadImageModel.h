//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface ThreadImageModel : ITTBaseModelObject

@property (nonatomic,strong) NSString *ImageID;
@property (nonatomic,strong) NSString *ImageUrl;
@property (nonatomic, strong) NSString *ImageWidth;
@property (nonatomic, strong) NSString *ImageHeight;
@end
