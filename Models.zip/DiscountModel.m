//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "DiscountModel.h"

@implementation DiscountModel
- (NSDictionary*)attributeMapDictionary
{
	return @{@"DiscountDes": @"DiscountDes"
             ,@"DiscountImage": @"DiscountImage"
             ,@"SpecialDes": @"SpecialDes"
             ,@"SpecialImage": @"SpecialImage"
             };
}
@end
