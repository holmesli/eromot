//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface DiscountModel : ITTBaseModelObject

@property (nonatomic,strong) NSString *DiscountDes;
@property (nonatomic,strong) NSString *DiscountImage;
@property (nonatomic,strong) NSString *SpecialDes;
@property (nonatomic,strong) NSString *SpecialImage;

@end
