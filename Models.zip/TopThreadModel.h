//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"
#import "ThreadImageModel.h"
#import "LikeComments.h"
#import "LikeModel.h"

@interface TopThreadModel : ITTBaseModelObject

@property (nonatomic,strong) NSString *ThreadID;
@property (nonatomic,strong) NSString *ThreadTitle;
@property (nonatomic,strong) NSString *ThreadPostDate;
@property (nonatomic,strong) NSString *ThreadContent;
@property (nonatomic,strong) NSString *ThreadUpdateDate;
@property (nonatomic,strong) NSMutableArray *ThreadImages;
@property (nonatomic,strong) NSString *ThreadType;
@property (nonatomic,strong) NSString *MemberID;
@property (nonatomic,strong) NSString *LastCommentDate;
@property (nonatomic, strong) NSMutableArray *listImage;
@property (nonatomic, strong) NSString *MemberImage;
@property (nonatomic, strong) NSString *AccountName;
@property (nonatomic, strong) NSString *TimeDiff;
- (void)addImageToList:(ThreadImageModel *)aImage;
@end
