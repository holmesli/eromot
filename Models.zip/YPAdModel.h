//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface YPAdModel : ITTBaseModelObject

@property (nonatomic,strong) NSString *AdID;
@property (nonatomic,strong) NSString *Title;
@property (nonatomic,strong) NSString *Content;
@property (nonatomic,strong) NSString *MemberID;
@property (nonatomic,strong) NSString *PostDate;
@property (nonatomic,strong) NSString *UpdateDate;
@property (nonatomic,strong) NSString *ServiceRegion;
@property (nonatomic,strong) NSString *Address;
@property (nonatomic,strong) NSString *Longitude;
@property (nonatomic,strong) NSString *Latitude;
@property (nonatomic,strong) NSString *AccountName;
@property (nonatomic,strong) NSString *Email;
@property (nonatomic,strong) NSString *Role;
@property (nonatomic,strong) NSString *Contact;
@property (nonatomic,strong) NSString *Language_M;
@property (nonatomic,strong) NSString *Language_C;
@property (nonatomic,strong) NSString *Language_E;
@property (nonatomic,strong) NSString *Phone1;
@property (nonatomic,strong) NSString *Phone2;
@property (nonatomic, strong) NSString *Url;

@end
