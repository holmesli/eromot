//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface CardModel : ITTBaseModelObject
{    NSString *_CardID;
    NSString *_CardType;
    NSString *_CardTitle;
    NSString *_CardBarcode;
    NSString *_CardNumber;
    NSString *_CardDes;
    NSString *_FrontViewImage;
    NSString *_BackViewImage;
}

@property (nonatomic,strong) NSString *CardID;
@property (nonatomic,strong) NSString *CardType;
@property (nonatomic,strong) NSString *CardTitle;
@property (nonatomic,strong) NSString *CardBarcode;
@property (nonatomic,strong) NSString *CardNumber;
@property (nonatomic,strong) NSString *CardDes;
@property (nonatomic,strong) NSString *FrontViewImage;
@property (nonatomic,strong) NSString *BackViewImage;

-(BOOL)hasFrontImage;
-(BOOL)hasBackImage;


@end
