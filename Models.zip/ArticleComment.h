//
//  Car.h
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTBaseModelObject.h"

@interface ArticleComment : ITTBaseModelObject


@property (nonatomic,strong) NSString *CommentID;
@property (nonatomic,strong) NSString *MemberID;
@property (nonatomic,strong) NSString *CommentContent;
@property (nonatomic,strong) NSString *PostDate;
@property (nonatomic,strong) NSString *UpdateDate;
@property (nonatomic,strong) NSString *AccountName;
@property (nonatomic, strong) NSString *TimeDiff;

@end
