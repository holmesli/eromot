//
//  Car.m
//  iTotemFrame
//
//  Created by Rainbow Zhang on 12/27/11.
//  Copyright (c) 2011 iTotemStudio. All rights reserved.
//

#import "LikeComments.h"

@implementation LikeComments


- (NSDictionary*)attributeMapDictionary
{
	return @{@"CommentPostDate": @"CommentPostDate"
             ,@"CommentContent": @"CommentContent"
             ,@"MemberID": @"MemberID"
             ,@"AccountName": @"AccountName"
             ,@"MemberImage": @"MemberImage"
             };
}


- (id)init
{
    self = [super init];
    if (self) {
        //self.models = [NSMutableArray array];
    }
    return self;
}

@end
